const pg = require('pg');

const client = new pg.Client({
    user: 'postgres',
    host: 'localhost',
    database: 'dwteste',
    password: 'postgres',
    port: 5433
})

module.exports = client;