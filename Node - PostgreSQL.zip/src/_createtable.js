const db = require('./_database');

async function createTable(){
    await db.connect();
    
    await db.query(`CREATE TABLE aluno(
        id serial PRIMARY KEY,
        nome VARCHAR(200)
    )`);

    console.log('Tabelas criadas');

    await db.end();
}

createTable();