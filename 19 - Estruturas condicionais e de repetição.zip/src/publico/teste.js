function msg(){
    alert('Oi - do arquivo teste.js');
}

//msg();