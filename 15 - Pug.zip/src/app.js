import express from 'express';
import path from 'path';

const app = express();

/**
 * Configurações estáticas
 */
app.use('/bscss', express.static('./node_modules/bootstrap/dist/css'));
app.use('/bsjs', express.static('./node_modules/bootstrap/dist/js'));
app.use('/jquery', express.static('./node_modules/jquery/dist'));
app.use('/popperjs', express.static('./node_modules/popper.js/dist/umd'));
app.use('/publico', express.static(__dirname + '/publico'));

/**
 * Configurações das páginas
 */
app.set('views',path.join(__dirname,'views'));
app.set('view engine','pug');

/**
 * Rotas de teste
 */
app.get('/teste', function (req, resp) {
    resp.render('teste');
});

/**
 * Rotas da aplicação
 */
app.get('/personalidadesNegras', function (req, resp) {
    resp.render('PersonalidadesNegras');
});

app.get('/', function (req, resp) {
    resp.render('PersonalidadesNegras');
});

export default app;